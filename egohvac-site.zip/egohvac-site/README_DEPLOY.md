# EGO HVAC — egohvac.com

Static website for EGO HVAC LV.

## Deploy (Netlify easiest)
1) Drag this folder into Netlify: Add new site → Deploy manually.
2) Add custom domain egohvac.com.
3) Enable HTTPS.
4) Test /buyback and /holidayheat.

## Tracking
- Replace CSP hosts in _headers if adding GTM/Meta.
- Add events by replacing the track() calls in HTML/JS.
